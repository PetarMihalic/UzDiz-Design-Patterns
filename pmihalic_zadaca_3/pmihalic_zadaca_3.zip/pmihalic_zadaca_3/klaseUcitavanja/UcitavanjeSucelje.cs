﻿using pmihalic_zadaca_3.klase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pmihalic_zadaca_3.loaders
{
    public interface UcitavanjeSucelje
    {
        public static object KreirajObjekt(string[] polja)
        {
            return null;
        }

        public static Boolean ProvjeraZapisa(string[] polja)
        {
            return false;
        }
    }
}
