﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pmihalic_zadaca_3.Composite
{
    public interface IBrodskaLukaComponent
    {
        List<Object> DohvatiDjecu();
    }
}
